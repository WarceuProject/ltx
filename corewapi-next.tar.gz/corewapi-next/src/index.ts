import makeWASocket, * as baileys from '@whiskeysockets/baileys'


Object.defineProperty(exports, 'baileys', {
	get () { return baileys },
	enumerable: true
})
Object.defineProperty(exports, 'createFactory', {
	value: function createFactory() {
		return baileys
	},
	enumerable: true
})

export * from '@whiskeysockets/baileys'
export default makeWASocket
// export * from '@adiwajshing/baileys'
// export { default } from '@adiwajshing/baileys'