import makeWASocket, * as baileys from '@adiwajshing/baileys'


Object.defineProperty(exports, 'baileys', {
	get () { return baileys },
	enumerable: true
})

export * from '@adiwajshing/baileys'
export default makeWASocket
// export * from '@adiwajshing/baileys'
// export { default } from '@adiwajshing/baileys'